# 🌡️ STM32 Temperature-Based State Tracking System

This project implements a temperature-monitoring system on the **STM32 Blue Pill (STM32F103C8T6)** using state transitions such as `IDLE`, `HEATING`, `TARGET_REACHED`, and `COOLING`. It simulates sensor readings and controls an LED based on the temperature thresholds.

---

## 📋 Features

- 🧠 Finite State Machine (FSM)-based design
- 🔥 Simulated heating and cooling logic
- 🌡️ Temperature readings (via analog input or simulated)
- 💡 LED indication for system state
- 🧵 Optional FreeRTOS support (configurable)
- 🛠️ Ready for STM32CubeIDE or PlatformIO

---

## 🧰 Components Used

| Component         | Details                                  |
|------------------|-------------------------------------------|
| MCU              | STM32F103C8T6 (Blue Pill)                 |
| Sensor (optional)| NCP / Analog Temp Sensor (Simulated)     |
| LED              | Connected to GPIO Pin (e.g., B1,B2,B10)        |
| Serial Monitor   | For debugging system state                |
| Power Supply     | 3.3V or via USB                           |

---

## 🔌 Pin Configuration

| Purpose       | Pin        |
|---------------|------------|
| Temperature In| A0 (ADC1) |
| State RED LED     | B1       |
| State GREEN LED     | B2       |
| State YELLOW LED     | B10       |
| I2C-> SCL       |         |
| I2C-> SDL       |       |

---

## 🔄 System Logic

```mermaid
stateDiagram-v2
    [*] --> IDLE
    IDLE --> HEATING : temp < target
    HEATING --> TARGET_REACHED : temp >= target
    TARGET_REACHED --> COOLING : timer expires
    COOLING --> IDLE : temp < lower threshold
    COOLING --> HEATING : temp >= target